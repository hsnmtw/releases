
document.querySelectorAll('[data-hr-main]').forEach(el => {
    const args = {
        Page: 1
    };
    GET('/hr/employee/query',args,function(model){
        el.innerHTML = `
        <table class="stats-table">
            <thead><tr>
                <th>Employee Num</th>
                <th>NameEn</th>
                <th>NameAr</th>
            </tr></thead>
            <tbody>
            ${model.Data.map(e => `
                <tr>
                    <td>${e.EmployeeNum}</td>
                    <td>${e.NameEn}</td>
                    <td>${e.NameAr}</td>
                </tr>
            `)}
            </tbody>
        </table>
        `;
    });
})