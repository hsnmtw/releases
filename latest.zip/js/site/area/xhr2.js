﻿const xhr2 = {
    GET(api, data, onSuccess, onFailure) {
       const encrypted = encryption.base64.encode(JSON.stringify({
        HttpMethod: 'GET',
        Action: api,
        Arguments: JSON.stringify(data)
       }));
       return xhr.GET('/',{e:encrypted},onSuccess,onFailure);
    },
    POST(api, data, onSuccess, onFailure) {
        const encrypted = encryption.base64.encode(JSON.stringify({
         HttpMethod: 'POST',
         Action: api,
         Arguments: JSON.stringify(data)
        }));
        return xhr.POST('/',{e:encrypted},onSuccess,onFailure);
    },
    DELETE(api, data, onSuccess, onFailure) {
        const encrypted = encryption.base64.encode(JSON.stringify({
         HttpMethod: 'DELETE',
         Action: api,
         Arguments: JSON.stringify(data)
        }));
        return xhr.POST('/',{e:encrypted},onSuccess,onFailure);
    }
}