delete from [etc_group] where [Id] in (158,157);
delete from [etc_usergroup] where [id]=4515;
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2427781428');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1089183402');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1070412810');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1065894477');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1061706493');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1064916149');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1065779025');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1037180591');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1063264160');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1091677821');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1070703317');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1102470315');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1067415578');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1037852025');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1041232990');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1066345537');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1074442938');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1061267421');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1074216910');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2501219949');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2557627649');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2375135668');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2382017263');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2485173401');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1068812997');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1105674285');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2501219212');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1014894800');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1011541578');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1026876175');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1051808135');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1081820159');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1045730841');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1088826191');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1071160970');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2493811703');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2376285967');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2561757044');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2423905187');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2230572246');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2539140349');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2336059502');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1040260505');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2408130157');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1060321179');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2285292500');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1055823387');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1031447863');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1020436604');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1039287527');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2337714618');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1060397898');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2364460853');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2491504151');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1088437080');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1067295541');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1090820992');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1034782100');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1055394553');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2446958569');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1063688046');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1007865395');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1084570777');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2410282988');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1066942648');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1040564294');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2388765782');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2366820633');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1042782811');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1095625909');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1006373847');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1094229430');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1095392401');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1016860163');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1059195097');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1087626519');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1065180950');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1050783073');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2501822627');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2336060146');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1055003238');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1066320720');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1083338531');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1045447354');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1028391504');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1080852484');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1016949669');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1057729079');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1080193772');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1105560054');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1065634063');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1093812558');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1080768433');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1061912315');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1078415468');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1067619211');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1123407130');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1092088994');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1098854076');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1059189850');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1016122135');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1128965397');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2416470710');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1076324647');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2458389646');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2367846884');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1075941466');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2271861250');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1051675716');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2016008571');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1069056099');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1059673440');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1082172436');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1037481486');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1039482920');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1003163134');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2416290647');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1101502100');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1095824627');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1081164525');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2187162256');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1070475171');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1000248532');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1069311718');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2008738953');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1074461888');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2453108710');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1087404164');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1067181634');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1069407169');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2466361090');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1047924533');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2476752668');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1035842861');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1052317862');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2365236443');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1060996434');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1075132520');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('2196183756');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1121620551');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1127460929');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1202249452');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1110651310');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('0500437083');
update common_user set isenabled=1,updatedby='auto',updatedon=getdate() where nationalid in ('1104755167');
update common_user set isenabled=0 where updatedby != 'auto';

-----
-- SELECT 'drop '||[type]||' '||[name]||';' FROM sqlite_master where ([name] like 'hr_%' or [name] like 'epolicY%' or [name] like 'Security_%' or [name] like 'etickets_%' or [name] like 'crashcart_%' or [name] like 'common_%' or [name] like 'eHR_%' or [name] like 'ESERVICES_%' or [name] in ('RolesCollections','UserActivity') );
-----

-- drop table [common_AccessType];
-- drop table [common_ApprovalRequest];
-- drop table [common_Area];
-- drop table [common_AssetLabel];
-- drop table [common_AutomatedUpgrade];
-- drop table [common_BuildingFloorDepartment];
-- drop table [common_BuildingFloor];
-- drop table [common_Building];
-- drop table [common_Bundle];
-- drop table [common_Cookie];
-- drop table [common_Country];
-- drop table [common_Department];
-- drop table [common_DomainComputer];
-- drop table [common_DomainGroup];
-- drop table [common_Email];
-- drop table [common_Floor];
-- drop table [common_GroupMembership];
-- drop table [common_JobTitle];
-- drop table [common_Location];
-- drop table [common_PINSMS];
-- drop table [common_ProfileDocument];
-- drop table [common_Profile];
-- drop table [common_ScheduledTaskExecution];
-- drop table [common_ScheduledTask];
-- drop table [common_ServerCommunication];
-- drop table [common_Session];
-- drop table [common_SMS];
-- drop view [common_VW_TechnicianTickets];
-- drop table [common_TemporaryFile];
-- drop table [common_Upgrade];
-- drop table [common_UserLoginAttempt];
-- drop table [common_UserManagerHistory];
-- drop table [common_User];
-- drop table [common_UserRegstrationAttachment];
-- drop table [common_UserRegstrationAttachmentTemplate];
-- drop table [common_UserRegistration];
-- drop table [common_UserTransfer];
-- drop table [crashcart_CartAuthorization];
-- drop table [crashcart_CartItem];
-- drop table [crashcart_Cart];
-- drop table [crashcart_CartNote];
-- drop table [crashcart_CartVersion];
-- drop table [crashcart_Signature];
-- drop table [crashcart_TemplateItem];
-- drop table [crashcart_Template];
-- drop table [crashcart_Unit];
-- drop table [ePolicy_Committee];
-- drop table [ePolicy_OnBehalfSignatureAuthorization];
-- drop table [ePolicy_PolicyAttachment];
-- drop table [ePolicy_PolicyAudit];
-- drop view [ePolicy_VW_PolicyAuthors];
-- drop table [ePolicy_PolicyLabel];
-- drop table [ePolicy_Policy];
-- drop table [ePolicy_PolicyNote];
-- drop view [ePolicy_VW_PolicyPendingSignatories];
-- drop table [ePolicy_PolicyRequestChangeItem];
-- drop table [ePolicy_PolicyRequestChange];
-- drop table [ePolicy_PolicyRequestDelete];
-- drop view [ePolicy_VW_PolicyRequest];
-- drop table [ePolicy_PolicyRequestRevision];
-- drop table [ePolicy_PolicyRequestSignatory];
-- drop table [ePolicy_PolicyRequestWithdraw];
-- drop view [ePolicy_VW_PolicySignatoriesJoined];
-- drop table [ePolicy_PolicySignatory];
-- drop view [ePolicy_VW_PolicyStatusByUser];
-- drop table [ePolicy_PolicyStatusHistory];
-- drop view [ePolicy_VW_PolicySummary];
-- drop table [ePolicy_PolicyTemplateConfiguration];
-- drop table [ePolicy_PolicyTemplate];
-- drop table [ePolicy_PolicyTemplateSignatory];
-- drop table [ePolicy_PolicyTerminationAudit];
-- drop table [ePolicy_PolicyTerminationCommittee];
-- drop table [ePolicy_PolicyTermination];
-- drop view [ePolicy_VW_PolicyTerminationPendingSignatories];
-- drop table [ePolicy_PolicyTerminationReason];
-- drop view [ePolicy_VW_PolicyTerminationSignatoriesJoined];
-- drop table [ePolicy_PolicyTerminationSignatory];
-- drop table [ePolicy_PolicyUpdateRequest];
-- drop table [ePolicy_PolicyVersion];
-- drop table [ePolicy_PolicyVersionSignatory];
-- drop table [ePolicy_Department];
-- drop table [ePolicy_SignatureAuthorization];
-- drop table [ePolicy_SignatureChangeRequest];
-- drop table [ePolicy_Signature];
-- drop table [ePolicy_Workspace];
-- drop table [ePolicy_WorkspacePolicy];
-- drop table [ePolicy_DocumentRequestField];
-- drop table [ePolicy_DocumentRequest];
-- drop table [ePolicy_DocumentRequestSigner];
-- drop table [ePolicy_DocumentTemplateField];
-- drop table [ePolicy_DocumentTemplate];
-- drop table [ePolicy_DocumentTemplateSigner];
-- drop table [ePolicyACO_Committee];
-- drop table [ePolicyACO_OnBehalfSignatureAuthorization];
-- drop table [ePolicyACO_PolicyAttachment];
-- drop table [ePolicyACO_PolicyAudit];
-- drop view [ePolicyACO_VW_PolicyAuthors];
-- drop table [ePolicyACO_PolicyLabel];
-- drop table [ePolicyACO_Policy];
-- drop table [ePolicyACO_PolicyNote];
-- drop view [ePolicyACO_VW_PolicyPendingSignatories];
-- drop table [ePolicyACO_PolicyRequestChangeItem];
-- drop table [ePolicyACO_PolicyRequestChange];
-- drop table [ePolicyACO_PolicyRequestDelete];
-- drop view [ePolicyACO_VW_PolicyRequest];
-- drop table [ePolicyACO_PolicyRequestRevision];
-- drop table [ePolicyACO_PolicyRequestSignatory];
-- drop table [ePolicyACO_PolicyRequestWithdraw];
-- drop view [ePolicyACO_VW_PolicySignatoriesJoined];
-- drop table [ePolicyACO_PolicySignatory];
-- drop view [ePolicyACO_VW_PolicyStatusByUser];
-- drop table [ePolicyACO_PolicyStatusHistory];
-- drop view [ePolicyACO_VW_PolicySummary];
-- drop table [ePolicyACO_PolicyTemplateConfiguration];
-- drop table [ePolicyACO_PolicyTemplate];
-- drop table [ePolicyACO_PolicyTemplateSignatory];
-- drop table [ePolicyACO_PolicyTerminationAudit];
-- drop table [ePolicyACO_PolicyTerminationCommittee];
-- drop table [ePolicyACO_PolicyTermination];
-- drop view [ePolicyACO_VW_PolicyTerminationPendingSignatories];
-- drop table [ePolicyACO_PolicyTerminationReason];
-- drop view [ePolicyACO_VW_PolicyTerminationSignatoriesJoined];
-- drop table [ePolicyACO_PolicyTerminationSignatory];
-- drop table [ePolicyACO_PolicyUpdateRequest];
-- drop table [ePolicyACO_PolicyVersion];
-- drop table [ePolicyACO_PolicyVersionSignatory];
-- drop table [ePolicyACO_Department];
-- drop table [ePolicyACO_Workspace];
-- drop table [ePolicyACO_WorkspacePolicy];
-- drop view [eTickets_VW_AwaitingTicket];
-- drop table [eTickets_ChecklistItem];
-- drop table [eTickets_Checklist];
-- drop table [eTickets_Issue];
-- drop table [eTickets_IssueNote];
-- drop table [eTickets_Priority];
-- drop table [eTickets_Question];
-- drop table [common_RaiseTicket];
-- drop table [common_ResetPasswordTicket];
-- drop table [eTickets_ResolutionAttachment];
-- drop table [eTickets_ResolutionCategory];
-- drop table [eTickets_Resolution];
-- drop table [eTickets_ServiceField];
-- drop table [eTickets_ServiceFieldResponse];
-- drop table [eTickets_Service];
-- drop table [eTickets_ServiceType];
-- drop table [eTickets_ServiceWorkflowTemplate];
-- drop table [eTickets_Setting];
-- drop view [eTickets_VW_TechnicianDailyStatusBreakdown];
-- drop table [eTickets_Template];
-- drop table [eTickets_TicketChecklist];
-- drop table [eTickets_TicketDailyOperationsSummary];
-- drop table [eTickets_TicketDailySummary];
-- drop table [eTickets_TicketLabel];
-- drop table [eTickets_TicketMetric];
-- drop table [eTickets_Ticket];
-- drop table [eTickets_TicketMonthlySummary];
-- drop table [eTickets_TicketNote];
-- drop table [eTickets_TicketStatus];
-- drop table [eTickets_TicketSurvey];
-- drop view [eTickets_VW_TicketTaskAssignment];
-- drop table [eTickets_TicketTask];
-- drop view [eTickets_VW_TicketTechnicianMonthlySummary];
-- drop table [eTickets_TicketWorkflowApprover];
-- drop view [eTickets_VW_TicketWorkflowApproverStatus];
-- drop table [eTickets_TicketWorkflow];
-- drop view [common_VW_UnassignedTicket];
-- drop table [hr_AttendanceSheet];
-- drop table [hr_AttendanceSheetUploadHistory];
-- drop table [hr_AttendanceSheetUpload];
-- drop table [hr_Document];
-- drop table [hr_DocumentType];
-- drop table [hr_Employee];
-- drop table [hr_EmployeeRequiredTraining];
-- drop table [hr_HRDepartment];
-- drop table [hr_Trainee];
-- drop table [hr_Training];
-- drop table [eHR_JobFamily];
-- drop table [UserActivity];
-- drop table [eServices_Agent];
-- drop table [eServices_AuthorizationArea];
-- drop table [eServices_AuthorizationDomainGroup];
-- drop table [eServices_Authorization];
-- drop table [eServices_AuthorizationRole];
-- drop table [eServices_MenuItem];
-- drop table [eServices_Menu];
-- drop table [eServices_Role];
-- drop table [RolesCollections];
-- drop table [eServices_SMS];
-- drop table [eServices_UrlShortner];
-- drop table [ePolicyTEST_Committee];
-- drop table [ePolicyTEST_PolicyAttachment];
-- drop table [ePolicyTEST_PolicyAudit];
-- drop table [ePolicyTEST_PolicyLabel];
-- drop table [ePolicyTEST_Policy];
-- drop table [ePolicyTEST_PolicyNote];
-- drop table [ePolicyTEST_PolicyRequestChangeItem];
-- drop table [ePolicyTEST_PolicyRequestChange];
-- drop table [ePolicyTEST_PolicyRequestDelete];
-- drop table [ePolicyTEST_PolicyRequestRevision];
-- drop table [ePolicyTEST_PolicyRequestSignatory];
-- drop table [ePolicyTEST_PolicyRequestWithdraw];
-- drop table [ePolicyTEST_PolicySignatory];
-- drop table [ePolicyTEST_PolicyStatusHistory];
-- drop table [ePolicyTEST_PolicyTemplateConfiguration];
-- drop table [ePolicyTEST_PolicyTemplate];
-- drop table [ePolicyTEST_PolicyTemplateSignatory];
-- drop table [ePolicyTEST_PolicyTerminationAudit];
-- drop table [ePolicyTEST_PolicyTerminationCommittee];
-- drop table [ePolicyTEST_PolicyTermination];
-- drop table [ePolicyTEST_PolicyTerminationReason];
-- drop table [ePolicyTEST_PolicyTerminationSignatory];
-- drop table [ePolicyTEST_PolicyUpdateRequest];
-- drop table [ePolicyTEST_PolicyVersion];
-- drop table [ePolicyTEST_PolicyVersionSignatory];
-- drop table [ePolicyTEST_Workspace];
-- drop table [ePolicyTEST_WorkspacePolicy];
-- drop table [ePolicyTEST_DocumentRequestField];
-- drop table [ePolicyTEST_DocumentRequest];
-- drop table [ePolicyTEST_DocumentRequestSigner];
-- drop table [ePolicyTEST_DocumentTemplateField];
-- drop table [ePolicyTEST_DocumentTemplate];
-- drop table [ePolicyTEST_DocumentTemplateSigner];
-- drop table [hr_ApprovalGroupMember];
-- drop table [hr_ApprovalGroup];
-- drop view [ePolicyTEST_VW_PolicyAuthors];
-- drop view [ePolicyTEST_VW_PolicyPendingSignatories];
-- drop view [ePolicyTEST_VW_PolicyRequest];
-- drop view [ePolicyTEST_VW_PolicySignatoriesJoined];
-- drop view [ePolicyTEST_VW_PolicyStatusByUser];
-- drop view [ePolicyTEST_VW_PolicySummary];
-- drop view [ePolicyTEST_VW_PolicyTerminationPendingSignatories];
-- drop view [ePolicyTEST_VW_PolicyTerminationSignatoriesJoined];
-- drop view [eServices_VW_MenuRoleAuthorization];
------------------------------------------------------------------
-- drop table [etc_User];
-- drop table [etc_Group];
-- drop table [etc_UserGroup];
-- drop table [etc_UserPasswordCache];
-- drop table [etc_temp];
----

-- select name from sqlite_master where type in ('table','view') and name like 'etc_%';

-- ALTER TABLE `foo` RENAME TO `bar`
-- ALTER TABLE [etc_User] RENAME TO [etc_User_old];
-- ALTER TABLE [etc_Group] RENAME TO [etc_Group_old];
-- ALTER TABLE [etc_UserGroup] RENAME TO [etc_UserGroup_old];
-- ALTER TABLE [etc_UserPasswordCache] RENAME TO [etc_UserPasswordCache_old];

-- -- db=Microsoft.Data.Sqlite
-- CREATE TABLE [etc_group] (
--    [Id] Integer NOT NULL    PRIMARY KEY AUTOINCREMENT,
--    [Name] NVARCHAR(255) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [Owner] NVARCHAR(50) COLLATE NOCASE   ,
--    [FQDN] NVARCHAR(255) COLLATE NOCASE  NOT NULL  DEFAULT '!'
--  , CONSTRAINT [UK_etc_group_pdb] UNIQUE([Name])
--  , CONSTRAINT [UK_etc_group_pdo] UNIQUE([FQDN])
-- );
-- -- db=Microsoft.Data.Sqlite
-- CREATE TABLE [etc_usergroup] (
--    [Id] Integer NOT NULL    PRIMARY KEY AUTOINCREMENT,
--    [GroupName] NVARCHAR(255) COLLATE NOCASE  NOT NULL ,
--    [Username] NVARCHAR(255) COLLATE NOCASE NOT NULL
--  , CONSTRAINT [UK_etc_usergroup_vdx] UNIQUE([GroupName],[Username])
-- );
-- -- db=Microsoft.Data.Sqlite
-- CREATE TABLE [etc_user] (
--    [Id] Integer NOT NULL    PRIMARY KEY AUTOINCREMENT,
--    [ExpiryDate] DATETIME   ,
--    [Username] NVARCHAR(50) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [Manager] NVARCHAR(50) COLLATE NOCASE   ,
--    [NameEn] NVARCHAR(200) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [NameAr] NVARCHAR(200) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [Email] NVARCHAR(255) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [GivenNameEn] NVARCHAR(255) COLLATE NOCASE   ,
--    [MiddleNameEn] NVARCHAR(255) COLLATE NOCASE   ,
--    [ThirdNameEn] NVARCHAR(255) COLLATE NOCASE   ,
--    [SurNameEn] NVARCHAR(255) COLLATE NOCASE   ,
--    [GivenNameAr] NVARCHAR(255) COLLATE NOCASE   ,
--    [MiddleNameAr] NVARCHAR(255) COLLATE NOCASE   ,
--    [ThirdNameAr] NVARCHAR(255) COLLATE NOCASE   ,
--    [SurNameAr] NVARCHAR(255) COLLATE NOCASE   ,
--    [Password] NVARCHAR(100) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [NationalId] NVARCHAR(100) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [Nationality] NVARCHAR(200) COLLATE NOCASE   ,
--    [EmployeeId] NVARCHAR(10) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [Mobile] NVARCHAR(20) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [FailedLoginAttempts] Integer NOT NULL DEFAULT 0   ,
--    [LastUsed] DATETIME   ,
--    [CreatedOn] DATETIME   ,
--    [LastPasswordResetOn] DATETIME   ,
--    [PasswordExpiry] DATETIME   ,
--    [IsEnabled] BIT NOT NULL DEFAULT 0
--  , CONSTRAINT [UK_etc_user_hbq] UNIQUE([Username])
-- );
-- -- db=Microsoft.Data.Sqlite
-- CREATE TABLE [etc_UserPasswordCache] (
--    [Id] Integer NOT NULL    PRIMARY KEY AUTOINCREMENT,
--    [Username] NVARCHAR(50) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [Password] NVARCHAR(100) COLLATE NOCASE  NOT NULL  DEFAULT '!' ,
--    [CreatedOn] DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00'
-- );


-- INSERT INTO [etc_User] ([ExpiryDate],[Username],[Manager],[NameEn],[NameAr],[Email],[GivenNameEn],[MiddleNameEn],[ThirdNameEn],[SurNameEn],[GivenNameAr],[MiddleNameAr],[ThirdNameAr],[SurNameAr],[Password],[NationalId],[Nationality],[EmployeeId],[Mobile],[FailedLoginAttempts],[LastUsed],[CreatedOn],[LastPasswordResetOn],[PasswordExpiry],[IsEnabled]) SELECT [ExpiryDate],[Username],[Manager],[NameEn],[NameAr],[Email],[GivenNameEn],[MiddleNameEn],[ThirdNameEn],[SurNameEn],[GivenNameAr],[MiddleNameAr],[ThirdNameAr],[SurNameAr],[Password],[NationalId],[Nationality],[EmployeeId],[Mobile],[FailedLoginAttempts],[LastUsed],[CreatedOn],[LastPasswordResetOn],[PasswordExpiry],[IsEnabled] FROM [etc_User_old];
-- INSERT INTO [etc_Group] ([Name],[Owner],[FQDN]) SELECT [Name],[Owner],[FQDN] FROM [etc_Group_old];
-- INSERT INTO [etc_UserGroup] ([GroupName],[Username]) SELECT [GroupName],[Username] FROM [etc_UserGroup_old] WHERE [GroupName] is not null and [Username] is not null;
-- INSERT INTO [etc_UserPasswordCache] ([Username],[Password],[CreatedOn]) SELECT [Username],[Password],[CreatedOn] FROM [etc_UserPasswordCache_old];


alter table [hr_AttendanceSheet] add [Sunday] bit not null DEFAULT 1;
alter table [hr_AttendanceSheet] add [Monday] bit not null DEFAULT 1;
alter table [hr_AttendanceSheet] add [Tuesday] bit not null DEFAULT 1;
alter table [hr_AttendanceSheet] add [Wedensday] bit not null DEFAULT 1;
alter table [hr_AttendanceSheet] add [Thursday] bit not null DEFAULT 1;
alter table [hr_AttendanceSheet] add [Friday] bit not null DEFAULT 0;
alter table [hr_AttendanceSheet] add [Saturday] bit not null DEFAULT 0;