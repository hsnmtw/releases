delete from [etc_group] where [Id] in (158,157);
delete from [etc_usergroup] where [id]=4515;