alter table hr_Employee alter column AssignmentType NVARCHAR(60);
alter table hr_Employee alter column Department NVARCHAR(300) not null default '!';


