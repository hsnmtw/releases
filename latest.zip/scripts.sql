
alter Table [crashcart_cart] alter column [SecurityCode]            VARCHAR(10)      NOT NULL;
alter Table [crashcart_cart] alter column [CurrentSecurityCode]     VARCHAR(10)      ;
alter Table [crashcart_cart] alter column [LastSecurityCode]        VARCHAR(10)      ;
