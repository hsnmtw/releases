alter table hr_Employee alter column AssignmentType NVARCHAR(60);

